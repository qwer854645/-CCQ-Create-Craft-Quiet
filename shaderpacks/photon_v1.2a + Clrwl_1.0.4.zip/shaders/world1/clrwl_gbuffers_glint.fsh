#version 400 compatibility
#define WORLD_END
#define PROGRAM_GBUFFERS_ARMOR_GLINT
#define fsh
#include "/program/clrwl_glint.fsh"
